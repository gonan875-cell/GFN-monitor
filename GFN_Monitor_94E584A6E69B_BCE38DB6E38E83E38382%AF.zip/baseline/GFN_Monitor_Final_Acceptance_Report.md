# GFN Monitor — Phase 7 最終受入レポート（コード凍結）

## 判定の分離
| 区分 | 内容 |
|---|---|
| **自己判定（Claude）** | **Phase 7 最終受入: PASS 候補。** HOLD 条件（strict GUI gate の再発、再ビルド不一致、製品・テストの欠陥の発見）は 1 つも発生しなかった。製品ソース・既存テスト・設定の変更は **0 件**。 |
| **レビュー判定** | （レビュー担当が記入。自己判定は最終承認ではない） |
PASS 候補とする条件の裏側にある制約（§9）と、未解明のまま残した事実（§6、§8）を、承認判断の材料として併記する。

## 1. 対象と開始ゲート
| 項目 | 値 |
|---|---|
| 唯一の配布候補 | `GFN_Monitor_Release_Phase6.zip` |
| SHA-256（**展開前**に照合、指定値と完全一致） | `0b4fbbd5f544715dce2d6caaa8ddb7462420881eb68c504ff01a1db851fcd41f` |
| 構成 | 135 エントリ（ファイルのみ）、最上位 `fixC_work/`、599,616 bytes、展開後 2,599,544 bytes |
| Phase 4 PASS 基準 ZIP の SHA-256 | `9fd0fa3a64e5bcb3934fa719f6bf7e54d72773bb9e79ed24e373ff023669b12e` |
| 原本の保管 | 読み取り専用で保管。作業終了時も SHA-256 は `0b4fbbd5…` のまま（無変更） |
| 外側パック | `GFN_Phase7_Acceptance_Pack.zip` SHA-256 `abd7b87ffb4922fddf8b2bec29c96cf0a98198497f92c34af63f4d23d2e94ad3`。パック内 11 ファイルは自身の `SHA256SUMS.txt` と全て一致。指示書・引き継ぎ・Phase 6 判定は、アップロード版と同一（cmp） |
| 環境 | Linux 6.18.44（`fc-v153`）/ CPU 1 コア / 約 4 GB / Python 3.12.3 / pytest 9.1.1 / pandas 3.0.2 / numpy 2.4.4 / matplotlib 3.10.8 / Tk 8.6 / Xvfb 21.1.12。Noto Sans CJK JP を含む日本語フォントが導入済み。matplotlib のフォントキャッシュは既存（87,334 bytes、実行中に変化なし） |
| 変更 | **製品ソース・既存テスト・設定: 0 件**（下の §2、§5 で証明） |

## 2. ZIP 自体の直接監査（展開せずに検査）
| 検査 | 結果 |
|---|---|
| (A) 配布同梱の `tools/build_release.py audit --zip … --manifest <別途配布された監査 manifest>`（ZIP から 1 ファイルだけ取り出して実行） | **PASS、0 エラー**、exit 0 |
| (B) 独立 `zipfile` 検査（プロジェクトのツールを import しない） | **PASS**、exit 0 |
- 監査 manifest は、Phase 7 パックで別途配布されたもの（135 件、SHA-256 先頭 `d4116e69e093f969`）。
- 項目別の結果（(B)）: `__pycache__` / `.pyc` / `.pytest_cache` / 生成 PNG・画像 / ログ / 生の pytest ログ / tmp / backup / lock / runtime state / 資格情報ファイル名 / 作業素材（pickle・prof・bench）/ VCS・エディタ・venv / OS メタデータ = **全て 0**。重複 0、大小文字衝突 0、不正パス 0、CRC（全エントリ）OK。内容走査: キー様 **0**、開発者パス **0**、非 UTF-8 エントリ 0。manifest との差: 欠落 0・余分 0・ハッシュ不一致 0。
- 空ファイル 4 件は全て `__init__.py`（意図したパッケージ標識）。Windows パス文字列 2 件は `gfn_monitor_config.json` と `gfn_monitor/config.py` の Tesseract 既定値（意図した既定値）。

## 3. クリーン展開とコンパイル
| 項目 | 結果 |
|---|---|
| 空ディレクトリへ展開 | **135 ファイル**（Phase 6 で承認した件数。旧 136 ではない）。展開ツリー == 監査 manifest（欠落 0 / 余分 0 / 変更 0） |
| `python -m compileall -f -q`（強制、新しい pycache 出力先） | **exit 0、0.47 秒、104/104 件**（`.py` 104 本に対して新規 pyc 104 件。展開ツリー内の pyc は 0 件） |

## 4. 実行結果（コマンド・exit・時間・件数）
「pytest 時間」は pytest 内部の表示、「外側 wall」はラッパーによる実測。両者は別の値として扱う。CPU は user+sys。
| 実行（全て展開ツリー内、Xvfb は xvfb） | exit | pytest 時間 | 外側 wall | CPU | PASS/FAIL/SKIP/TIMEOUT | 警告 |
|---|---|---|---|---|---|---|
| **全体** `xvfb-run -a python3 -m pytest tests -p no:cacheprovider -q -rs -W default --durations=10` | 0 | 273.10 s | 279.44 s | 201.3 s | **804 PASS** / 0 FAIL / 0 SKIP / 0 TIMEOUT | **290** |
| **strict GUI + R5 gate** 1 回目 | 0 | 28.53 s | 29.59 s | 19.0 s | 10 PASS | 1 |
| strict GUI + R5 gate 2 回目 | 0 | 27.63 s | 28.78 s | 18.5 s | 10 PASS | 1 |
| strict GUI + R5 gate 3 回目 | 0 | 27.90 s | 28.85 s | 18.1 s | 10 PASS | 1 |
| CLI + migration E2E（14 件） | 0 | 35.26 s | 36.29 s | 9.0 s | 14 PASS | 1 |
| Stress（16 件） | 0 | 52.67 s | 53.30 s | 52.4 s | 16 PASS | 1 |
| smoke（graph + migration） | 0 | – | 3.99 s | 3.8 s | 14 チェック全 PASS | 0 |
- strict gate のコマンド: `env PYTHONWARNINGS=error xvfb-run -a python3 -m pytest tests/test_step14_e2e_gui.py tests/test_step14_r5_quality.py -p no:cacheprovider -q -rs`（`PYTHONWARNINGS=error` は pytest の子プロセスにだけ付与）。
- 件数の整合: Phase 4 PASS の 730 + Phase 6 追加の 74 = 804。
- **警告数 290 は提出環境（Python 3.12.3 / pytest 9.1.1）と一致**。別環境の値（独立レビュー環境の 293）とは混同していない。Phase 6 の正式実行と、展開先のパスを除いて比較した結果、**警告の差は 0 グループ**（合計 290 件、グループ 170 件）。内訳は `ResourceWarning` 169 グループ（発生元は既存テストコード: `tests/test_phase3_manual_derived_data.py` 168、`tests/test_r2_forecast_metric_semantics.py` 1）と `PytestConfigWarning` 1 グループ（`asyncio_default_fixture_loop_scope` が未知の設定。この環境に pytest-asyncio が無いため）。**警告は抑制していない**。

## 5. 同梱ファイルが無変更であることの確認
テスト実行後も、同梱の 135 ファイルは**全て変更されていない**（`ex_main`・`ex_fresh` の両方で、変更 0 / 欠落 0）。展開ツリーに増えたのは生成グラフ PNG 7 枚のみ（製品の既定 `graph_dir="."` による。再ビルドで除外される成果物と同じもの）。

## 6. strict GUI + R5 gate（再発したら HOLD）
- 指示された **3 回連続: 10 passed、exit 0 ×3**。
- 追加の証拠として、**きれいな新規展開**でも 3 回実行: 10 passed ×3（exit 0）。**合計 6 回、再発は 0**。実行ごとの環境（フォントキャッシュの大きさ・更新時刻、負荷）を記録した。キャッシュは全回で同一（87,334 bytes、更新時刻不変）。
- **過去の 1 回の失敗（Phase 6 提出時、7 failed / 3 passed）の原因は、今回も未解明のまま**。再発しなかったことは、原因の説明にはならない。環境・フォント要因とは断定しない。
- R6 gate の記述「warning 0」は、そのままの意味では再現していない（strict 実行でも pytest の設定警告が 1 件出る）。

## 7. 再ビルドのバイト一致（`tools/build_release.py` で、原本とは別のパスへ生成）
| 再ビルド元 | ツール exit | 除外されたパス | 生成 ZIP の SHA-256 | 固定候補との比較 |
|---|---|---|---|---|
| 全体テストを実行した**汚れた展開ツリー**（PNG 7 枚が残存） | 0 | 7 | `0b4fbbd5…41f` | **完全一致** |
| きれいな新規展開 | 0 | 0 | `0b4fbbd5…41f` | **完全一致** |
| 上記の新規展開で gate・stress を実行した後 | 0 | 7 | `0b4fbbd5…41f` | **完全一致** |
手作業の掃除はしていない。汚れたツリーの PNG は、ツールが ZIP に**書き込む前に**除外した。

## 8. 対照実験と所要時間について
- 全体 273.10 s は、Phase 6 の提出環境の記録（195.66 s）、Phase 6 の最初の実行（236.43 s）、独立レビュー環境（171.08 s）のいずれとも異なる。**同一ソースで実行ごとに大きく揺れる**ため、性能の判断に単発値を使わない。
- 同じ環境で、stress 群を Phase 4 PASS の基準ソースとリリース候補に交互に 2 回ずつ実行した: **基準 45.30 / 45.00 s、リリース 48.11 / 47.13 s**（各 16 passed）。両方とも Phase 5・6 の約 27 s より遅く、**このホストが遅い**ことを示す。リリースが約 5% 遅く出たが、製品コードは基準と同一（132 ファイルがバイト単位で同一）で、n=2 では有意とは言えず、**原因は確認していない**（Phase 6 の対照では逆にリリースの方が速かった）。
- 製品コードの差が無いことの確認: Phase 6 の分類（同一 132 / 変更 1 `RELEASE_PACKAGE.md` / 追加 2 `tools/build_release.py`・`tests/test_release_packaging.py` / 除外 3 `reports/step14_baseline_test*.txt`）。製品コード・データ・設定・既存テストの変更・追加・削除は無い。

## 9. Phase 4/5 の訂正値（元ログで再確認済み）
1. **Phase 4 diff（git numstat）: `domain/outlier.py` +108/−168、`tests/test_phase4_historical_contract.py` +252/−0、合計 +360/−168**。Phase 4 REPORT の `+306/−155` は誤り（空行を数えない集計規則による。空行も数える `diff -ruN` の集計では +358/−166 で、数え方が異なる）。
2. **100k 行の履歴フィルタ**: 過去の単発実測は **v4 4.27 s → Phase 4 PASS 5.65 s（1.32 倍）**。「5.6 → 5.7 s」は誤り。Phase 5 の反復中央値（各ツリー 14 サンプル）は **100k: 3.750 s → 5.149 s（1.37 倍）／ 10k: 0.389 s → 0.589 s（1.51 倍）／ 50k: 2.035 s → 2.879 s（1.41 倍）**。
3. **Phase 5 の stress**: v4・PASS それぞれ 3 回、**16/16 pass**。**cProfile 付きの 1 回は pytest 要約が `1 failed`（テスト自身の判定で 40.16 s > 40 s）で、PASS には数えない**（pytest 要約全体は 41.29 s）。
4. **lock 待ちとディスク I/O は直接測定されていない**（間接的な推論のみ）。**性能しきい値は仕様上未定義**。
5. **全体スイートの時間の表記**: Phase 5 の pytest 表示は v4 689 passed in 176.00 s、PASS 730 passed in 185.53 s。外側 wall は v4 179.75 s、PASS 186.22 s（別の値）。
6. **警告数 290 は提出環境の値**。別環境の値と混同しない。
7. 100k の出力件数の差（v4 98,427 / PASS 98,783）は、PASS が独立 Runtime oracle と一致し、v4 が受理すべき 385 行を落として受理しない 29 行を残していたことによる（AC-13 修正の効果であり、性能回帰ではない）。同梱データ（1,064 行・133 セッション）では、出力は同じ 1,055 行、フィルタ中央値は v4 0.073–0.096 s、PASS 0.090–0.104 s。
8. ZIP 内の旧 r4/r5/r6 報告と静的監査報告（522/525 件）は歴史記録。**現行統計の正本は本レポート（804 件）**。

## 10. 残存リスク・制約（承認判断の材料）
- **Windows 上のビルド・展開・実行は未検証**（対象アプリは Windows 向け。今回の検証はすべて Linux）。
- strict GUI gate の過去の 1 回の失敗は、**原因未解明のまま**（今回の再発は 0/6）。
- 履歴フィルタは 100k 行で約 1.37 倍遅い（約 +1.4 s）。しきい値が未定義のため、許容可否は未判断。
- 既存テストコードに起因する `ResourceWarning` が 169 グループある（`tests/test_phase3_manual_derived_data.py` の未クローズのファイルが主因）。コード凍結のため変更していない。
- 所要時間はホストで揺れる（今回 273 s、過去 171–236 s）。
- 製品の既定 `graph_dir="."` により、テスト実行で PNG が展開ツリーに残る。packaging の除外規則が防ぐが、製品挙動は未変更。

## 11. この作業中の私の誤り（結果への影響なし）
- 最初の直接監査は、`sh` の非対応構文で途中で止まり、(B) が実行されなかった。bash のスクリプトに直して、両方を再実行した。
- 追加実行のスクリプトに、存在しないディレクトリを指す不要な行を一度書いたが、実行前に削除した（結果ファイルに影響していない）。
- 警告の比較で、最初は展開先の絶対パスをキーに含めたため「14 グループが違う」と出た。パスを正規化して再比較し、差が 0 であることを確認した。

## 12. 提出物
`FINAL_ACCEPTANCE_REPORT.md` / `FINAL_RELEASE_SHA256.txt` / `GFN_Monitor_Release_Phase6.zip`（固定候補。原本と同一バイト）/ `GFN_Phase7_Test_Logs.zip`（全体テストログ、strict GUI gate 各ログ（6 回）、CLI/migration・stress・smoke ログ、監査結果、再ビルド一致結果、環境、対照実験、スクリプト）/ `start_manifest.sha256`（展開直後 135）/ `end_manifest.sha256`（テスト実行後 142、うち 7 は PNG）/ `audit_manifest_distributed.sha256`（別途配布の監査 manifest 135）/ `SHA256SUMS`
- 再現コマンドは logs ZIP の `scripts/`（`audit_zip.sh`、`extract_and_compile.sh`、`run_acceptance.sh`、`run_extra.sh`）。
- Phase 8 以降の作業は作っていない。
